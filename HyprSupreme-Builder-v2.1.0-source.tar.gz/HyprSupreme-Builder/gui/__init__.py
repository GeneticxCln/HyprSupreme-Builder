"""
HyprSupreme-Builder GUI Package
Contains the graphical user interface for HyprSupreme-Builder
"""

__version__ = "2.0.1"
__author__ = "HyprSupreme Team"

# Make modules available
__all__ = [
    "hyprsupreme_gui"
]

